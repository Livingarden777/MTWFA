UPLOAD TO GITHUB PAGES

1. Upload index.html to your GitHub Pages repository.
2. Open your GitHub Pages URL.
3. Click any underlined parenthetical Scripture reference.

The full KJV text is loaded from bible-api.com when the reader clicks a reference, so the reader must be online.
